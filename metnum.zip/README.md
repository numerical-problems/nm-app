## Necessário instalar:
- NodeJS: [link](https://nodejs.org/en/download/)

## Instalação de bibliotecas:

-   Faça o download do yarn [aqui](https://classic.yarnpkg.com/en/docs/install#windows-stable)
-   Após instalar o yarn, basta clonar ou baixar  o projeto e executar:
```shell
 yarn 
```

- Também é possível utilizar o comando 
```shell
 npm install
```
## Iniciar o servidor

```shell
 yarn start ou npm start
```

