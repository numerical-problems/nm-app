import React from "react";

import { Container } from "../../layout/container";
import Page from "../../layout/page";

function Logaritmos() {
  return (
    <Page id="logaritmos">
      <Container>
        <h1>Logaritmos</h1>
      </Container>
    </Page>
  );
}

export default Logaritmos;
